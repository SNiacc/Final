var CurrentImg;
var i=0;
document.getElementById("cycle").addEventListener("click", main);
function main(){
    switch(i){
        case (0):
            document.getElementById("image").src="Functions.jpg";
            i++;
            document.getElementById("expo").innerHTML=("All the Functions We have learned to Use");
        break;
        case (1):
            document.getElementById("image").src="HTML.jpg";
            i++;
            document.getElementById("expo").innerHTML=("All the HTML We Have Learned and used");
        break;
        case (2):
            document.getElementById("image").src="Random.jpg";
            i=0;
            document.getElementById("expo").innerHTML=("All the Random Numbers and Switch's We Have Used");
        break;
    }   
}